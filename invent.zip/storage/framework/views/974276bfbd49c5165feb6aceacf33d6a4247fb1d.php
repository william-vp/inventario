<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Chart Demo</div>
                
                <?php for($i= 0; $i < count($productos); $i++){ 
        	$nombre= $productos[$i]->nombre;
        ?>
    		'<?=$nombre?>'
    	<?php if (count($productos)-1 != $i){
    		echo ",";
    	}
    }
    	?>

                <div class="panel-body" id="containerChart">
                </div>
 
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/highcharts/6.0.6/highcharts.js" charset="utf-8"></script>
<script type="text/javascript">
	Highcharts.chart('containerChart', {
    chart: {
        type: 'bar'
    },
    title: {
        text: 'Productos Más Vendidos'
    },
    subtitle: {
        text: '<?= session('app_name') ?>'
    },
    xAxis: {
        categories: [

        <?php for($i= 0; $i < count($productos); $i++){ 
        	$nombre= $productos[$i]->nombre; ?>
    		'<?=$nombre?>'
    		<?php if (count($productos)-1 != $i){
    		echo ",";
    		} ?>

    	<?php } ?>
    	],title: {
            text: null
        }
    },
    yAxis: {
        min: 0,
        title: {
            text: 'Cantidad',
            align: 'high'
        },
        labels: {
            overflow: 'justify'
        }
    },
    tooltip: {
        valueSuffix: ''
    },
    plotOptions: {
        bar: {
            dataLabels: {
                enabled: true
            }
        }
    },
    legend: {
        layout: 'vertical',
        align: 'right',
        verticalAlign: 'top',
        x: -40,
        y: 80,
        floating: true,
        borderWidth: 1,
        backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
        shadow: true
    },
    credits: {
        enabled: false
    },
    series: [
    <?php  for($i= 0; $i < count($productos); $i++){ ?>
    	{
    		name: '<?=$productos[$i]->nombre ?>',
    		data: [<?=$productos[$i]->total_ventas?>]
    	}
    	<?php if (count($productos)-1 != $i){
    		echo ",";
    	} ?>

    <?php } ?>
    ]
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>