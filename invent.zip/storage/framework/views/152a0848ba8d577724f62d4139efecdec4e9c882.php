<?php $__env->startSection('title', 'Creditos'); ?>
<?php $__env->startSection('color-style', 'bg-primary'); ?>
<?php $__env->startSection('content'); ?>
    <h4 class="c-grey-900 mB-20 text-center text-primary">Lista de Creditos</h4>
    <div class="text-left container mb-3 p-0">
        <a class="btn btn-outline-primary" href="<?php echo e(URL::previous()); ?>"><i class="ti-arrow-left"></i> Volver</a>
    </div>
    <table id="tablaVentas" class="table table-hover" cellspacing="0" width="100%">
        <thead>
        <tr>
            <th>Id</th>
            <th>Fecha</th>
            <th>Cliente</th>
            <th>Caja</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id</th>
            <th>Fecha</th>
            <th>Cliente</th>
            <th>Caja</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
        </tfoot>
        <tbody>
        <?php $__currentLoopData = $creditos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credito): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($credito->id); ?></td>
                <td><?php echo e($credito->fecha); ?></td>
                <td><strong>Id: </strong> <?php echo e($credito->cliente_id); ?><br>
                    <strong>Nombre: </strong> <?php echo e($credito->nombre); ?>

                </td>
                <td><?php echo e($credito->caja_id); ?></td>

                <?php if($credito->estado == 1): ?>
                    <td><span class="badge bg-success text-white">PAGADO</span><br>
                        <a href="<?php echo e(route('factura.detalles', $credito->factura_id )); ?>">Ver Factura</a>
                    </td>
                <?php else: ?>
                    <td><span class="badge bg-info text-white">ACTIVO</span></td>
                <?php endif; ?>
                <td>
                    <a href="<?php echo e(route('creditos.abono', $credito->id)); ?>" data-toggle="tooltip" title="Realizar Abono" class="btn btn-success"><i class="ti-money text-white"></i></a>

                    <a href="<?php echo e(route('creditos.detalles', $credito->id)); ?>" data-toggle="tooltip" title="Información del Credito" class="btn btn-info"><i class="ti-info text-white"></i></a>

                    <!--<a href="{ route('creditos.destroy', $credito->id) }}" data-toggle="tooltip" title="Eliminar credito" onclick="return confirm('¿Seguro quieres eliminar este Credito?')" class="btn btn-danger"><i class="ti-trash"></i></a>-->
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </tbody>
    </table>

    <script src="<?php echo e(asset('js/scripts/auth.js')); ?>"></script>
    <script type="text/javascript">
        $('#tablaVentas').DataTable({
            "order": [1, "asc"]
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>