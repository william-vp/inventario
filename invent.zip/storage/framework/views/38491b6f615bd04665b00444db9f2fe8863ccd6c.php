<?php $__env->startSection('title', 'Abonos de Pedido'); ?>
<?php $__env->startSection('color-style', 'bg-primary'); ?>
<?php $__env->startSection('content'); ?>
<div class="row col-sm-12">

    <div class="col-xs-12 col-lg-6 col-sm-12">
    	<h3 class="text-center">Datos Credito</h3>
    		<div class="list-group">
    			<?php
    				$date= explode(' ',$credito->fecha);
    				$fecha= $date[0];
    				$hora= $date[1];
    			?>

                <a href="#" class="list-group-item list-group-item-action"><strong>Credito No:</strong> <?php echo e($credito->id); ?></a>
                <a href="#" class="list-group-item list-group-item-action"><strong>Fecha:</strong> <?php echo e($fecha); ?></a>
                <a href="#" class="list-group-item list-group-item-action"><strong>Hora:</strong> <?php echo e($hora); ?></a>
                <a href="#" class="list-group-item list-group-item-action"><strong>Id Proveedor:</strong> <?php echo e($credito->proveedor_id); ?></a>
                <a href="#" class="list-group-item list-group-item-action"><strong>Nombre:</strong> <?php echo e($credito->nombre); ?></a>

                <?php if($credito->estado_credito == 1): ?>
                	<a href="#" class="list-group-item list-group-item-action"><strong>Estado Credito:</strong> <span class="badge badge-success" style="font-size: 13px;"> PAGADO</span></a>
                <?php else: ?>
                	<a href="#" class="list-group-item list-group-item-action"><strong>Estado Credito:</strong> <span class="badge badge-warning text-white" style="font-size: 13px;"> ACTIVO</span></a>
                <?php endif; ?>

                <a href="#" class="list-group-item list-group-item-action"><strong>Obervaciones:</strong> <p><?php echo e($credito->observacion); ?></p></a>

                <a href="<?php echo e(route('pedidos_credito.detalles', $credito->id)); ?>" class="list-group-item list-group-item-action bg-info text-center text-white rounded-0 font-weight-bold btnClose"><i class="fa fa-list"></i> VER MÁS DETALLES</a>

            </div>


         <br>
    	<h3 class="text-center">Abonos Realizados: <?php echo e(count($abonos)); ?></h3>

		<table id="tablaAbonos" class="table table-hover" cellspacing="0" width="100%">
		<?php
			$valorCancelado= 0;
		?>
    	<?php if(count($abonos) > 0 ): ?>
            <thead class="bg-dark text-white">
            <tr>
                <th>Abono No</th>
                <th>Fecha</th>
                <th>Caja</th>
                <th>Valor Abono</th>
            </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $abonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $abono): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $valorCancelado= $valorCancelado + $abono->valor; ?>
                        <tr>
                            <td><?php echo e($abono->id); ?></td>
                            <td><?php echo e($abono->fecha); ?></td>
                            <td><?php echo e($abono->caja_id); ?></td>
                            <td>$<?php echo e(number_format($abono->valor,2,',','.')); ?></td>
                        </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
    	<?php endif; ?>
        	<tr>
                <td colspan="2">Valor Cancelado (Pagado)</td>
                <td colspan="2">$ <?php echo e(number_format( $valorCancelado ,2, ',' ,'.')); ?></td>
            </tr>
            <tr>
            	<?php $valorRestante= $credito->total - $valorCancelado; ?>
                <td colspan="2"> Valor Restante (Saldo) </td>
                <td colspan="2">$ <?php echo e(number_format($valorRestante ,2,',','.')); ?></td>
            </tr>
        </tbody>
	</table>

        
    </div>

    <div class="col-xs-12 col-lg-6 col-sm-12">

    		<?php if($credito->estado_credito == 0): ?>

            <div class="container">

				<h3 class="text-center">Realizar Abono</h3>

            <form id="formAbono" name="formAbono" method="post"><br>
                <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                <input type="hidden" value="<?php echo e($valorRestante); ?>" class="_inputVR">

                <div class="form-group">
                	<label>Valor Abono: </label>
                    <input type="number" min="1000" max="<?php echo e($valorRestante); ?>" class="form-control"  placeholder="$ Valor Inicial" name="valor_abono" id="valor_abono">
                </div>

                <div class="checkbox checkbox-circle checkbox-info peers ai-c">
                            <input type="checkbox" id="checkPayAll" name="checkPayAll" class="peer">
                            <label for="checkPayAll" class=" peers peer-greed js-sb ai-c">
                                <span class="peer peer-greed">Pagar Todo</span>
                            </label>
                </div>

                <div class="form-group text-center">
                    <button type="button" class="btn btn-success btnAbonoPedido"><i class="ti-save"></i> INGRESAR ABONO</button>
                </div>
            </form>
            </div>

            <?php else: ?>

            <div class="alert alert-success">
                <h1>CREDITO PAGADO</h1>
                ESTE CREDITO YA HA SIDO PAGADO TOTALMENTE.
            </div>

            <?php endif; ?>
    </div>
</div>

<script src="<?php echo e(asset('js/scripts/abono_pedido.js')); ?>"></script>
<script type="text/javascript">
    $('[data-toggle="tooltip"]').tooltip();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>