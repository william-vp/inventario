<?php $__env->startSection('title', 'No Tienes permisos para acceder a este sitio'); ?>
<?php $__env->startSection('color-style', 'bg-primary'); ?>
<?php $__env->startSection('content'); ?>

<div class="container">

	<div class="col-sm-10 text-center" align="left">
		<img src="<?php echo e(Storage::url('public/denied.png')); ?>" width="400" class="text-left">

		<a class="btn btn-outline-info" href="<?php echo e(URL::previous()); ?>"><i class="ti-back-left"></i> Regresar a la pagina anterior</a>

	</div>



</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>