<?php $__env->startSection('title', 'Realizar Pedido'); ?>
<?php $__env->startSection('color-style', 'bg-primary'); ?>
<?php $__env->startSection('content'); ?>
<div class="row col-sm-12">

    <div class="col-xs-12 col-lg-6 col-sm-12">
    	<h3 class="text-center text-primary">Datos Pedido</h3>
    		<div class="list-group">
    			<?php
    				$date= explode(' ',$pedido->fecha);
    				$fecha= $date[0];
    				$hora= $date[1];
    			?>

                <a href="#" class="list-group-item list-group-item-action"><strong>No.:</strong> <?php echo e($pedido->id); ?></a>
                <a href="#" class="list-group-item list-group-item-action"><strong>Fecha:</strong> <?php echo e($fecha); ?></a>
                <a href="#" class="list-group-item list-group-item-action"><strong>Hora:</strong> <?php echo e($hora); ?></a>
                <a href="#" class="list-group-item list-group-item-action"><strong>Id Proveedor:</strong> <?php echo e($pedido->proveedor_id); ?></a>
                <a href="#" class="list-group-item list-group-item-action"><strong>Nombre:</strong> <?php echo e($pedido->nombreProv); ?></a>

                
                <?php if($tipo == "credito"): ?>
                    <?php if($pedido->estado_credito == 1): ?>
                    <a href="#" class="list-group-item list-group-item-action"><strong>Estado Credito:</strong> <span class="badge badge-success" style="font-size: 13px;"> PAGADO</span></a>
                    <?php elseif($pedido->estado_credito == 0): ?>
                        <a href="#" class="list-group-item list-group-item-action"><strong>Estado Credito:</strong> <span class="badge badge-warning text-white" style="font-size: 13px;"> ACTIVO</span></a>
                    <?php endif; ?>

                <?php endif; ?>


                <?php if($pedido->estado_pedido == 0): ?>
                    <a href="#" class="list-group-item list-group-item-action"><strong>Estado Pedido:</strong> <span class="badge badge-info" 
                        style="font-size: 13px;"> SIN REALIZAR</span></a>
                <?php else: ?>
                        <a href="#" class="list-group-item list-group-item-action"><strong>Estado Pedido:</strong> <span class="badge badge-success text-white" style="font-size: 13px;"> REALIZADO</span></a>
                <?php endif; ?>
                

                <a href="#" class="list-group-item list-group-item-action"><strong>Obervaciones:</strong> <p><?php echo e($pedido->observacion); ?></p></a>


                <?php if($tipo == "credito"): ?>
                    <a href="<?php echo e(route('pedidos_credito.detalles', $pedido->id)); ?>" class="list-group-item list-group-item-action bg-info text-center text-white rounded-0 font-weight-bold btnClose"><i class="fa fa-list"></i> VER MÁS DETALLES</a>
                <?php else: ?>
                    <a href="<?php echo e(route('pedidos.detalles', $pedido->id)); ?>" class="list-group-item list-group-item-action bg-info text-center text-white rounded-0 font-weight-bold btnClose"><i class="fa fa-list"></i> VER MÁS DETALLES</a>
                <?php endif; ?>

            </div>
    </div>

    <div class="col-xs-12 col-lg-6 col-sm-12">

    		<?php if($pedido->estado_pedido == 0): ?>

            <div class="container">

				<h3 class="text-center text-primary">Realizar Pedido</h3>

            <form id="formGenerarPedido" name="formGenerarPedido" method="post"><br>
                <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                <input type="hidden" value="<?php echo e($pedido->id); ?>" name="_no">
                <input type="hidden" value="<?php echo e($tipo); ?>" name="_type">


                <label>Elija donde desea ubicar los productos solicitados en el pedido.</label>
                <div class="checkbox checkbox-circle checkbox-info peers ai-c">
                    <input type="checkbox" id="mostrador" value="0" name="ubicar" class="peer">
                    <label for="mostrador" class=" peers peer-greed js-sb ai-c">
                                <span class="peer peer-greed">Ubicar en Mostrador</span>
                    </label>
                </div>
                <div class="checkbox checkbox-circle checkbox-info peers ai-c">
                    <input type="checkbox" id="existencias" value="1" name="ubicar" class="peer">
                    <label for="existencias" class=" peers peer-greed js-sb ai-c">
                                <span class="peer peer-greed">Ubicar en Bodega</span>
                    </label>
                </div>

                <div class="form-group text-center">
                    <button type="button" class="btn btn-success btnGenerar"><i class="ti-save"></i> REALIZAR PEDIDO</button>
                </div>
            </form>
            </div>

            <?php else: ?>

            <div class="alert alert-success">
                <h1>PEDIDO REALIZADO</h1>
                ESTE PEDIDO YA HA SIDO REALIZADO.
            </div>

            <?php endif; ?>
    </div>
</div>

<script src="<?php echo e(asset('js/scripts/abono.js')); ?>"></script>
<script src="<?php echo e(asset('js/scripts/pedido.js')); ?>"></script>
<script type="text/javascript">
    $('[data-toggle="tooltip"]').tooltip();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>