<?php $__env->startSection('title', 'Inicio'); ?>
<?php $__env->startSection('color-style', 'bg-info'); ?>
<?php $__env->startSection('content'); ?>
<script type="text/javascript" src="<?php echo e(asset('js/numscroller.js')); ?>"></script>
<link rel="stylesheet" href="<?php echo e(asset('css/fullcalendar.min.css')); ?>"/>

<style type="text/css">
    .fc-today{
        background: red;
        color: #fff;
    }
    .fc td{
        color: red;
        font-weight: 500;
    }
    .fc-title{
        color: #fff;
        font-weight: 700;
        text-align: center;
    }
    .fc-content, .fc-event{
        background: #FF6E56;
        border: 1px solid transparent;
        text-align: center;
    }
</style>

<div class="container">
    <div class="row">
        <div class="col-md-3">
            <div class="bdrs-3 ov-h bgc-white border-0">
                <div class="ta-c p-30 bg-success">
                    <h1 class="fw-300 mB-5 lh-1 c-white numscroller" data-slno='1' data-min='0' data-max='<?php echo e($usuarios); ?>' data-delay='.5' data-increment="1"> <span class="fsz-def"></span></h1>
                    <h3 class="c-white">Usuarios</h3>
                </div>
                <div class="pos-r">
                    <button type="button" class="mT-nv-50 pos-a r-10 t-2 btn cur-p bdrs-50p p-0 w-3r h-3r btn-success mb-3 border-white">
                        <i class="ti-user"></i>
                    </button>
                    <ul class="m-0 p-0 mT-20 mb-3">
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="bdrs-3 ov-h bgc-white border-0">
                <div class="bgc-deep-orange-400 ta-c p-30">
                    <h1 class="fw-300 mB-5 lh-1 c-white numscroller" data-slno='1' data-min='0' data-max='<?php echo e($producto); ?>' data-delay='.5' data-increment="1"><span class="fsz-def"></span></h1>
                    <h3 class="c-white">Productos</h3>
                </div>
                <div class="pos-r">
                    <button type="button" class="text-white mT-nv-50 pos-a r-10 t-2 btn cur-p bdrs-50p p-0 w-3r h-3r btn-warning mb-3 border-white">
                        <i class="ti-layout-grid3"></i>
                    </button>
                    <ul class="m-0 p-0 mT-20 mb-3">
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="bdrs-3 ov-h bgc-white border-0">
                <div class="bg-primary ta-c p-30">
                    <h1 class="fw-300 mB-5 lh-1 c-white numscroller" data-slno='1' data-min='0' data-max='<?php echo e($ventas); ?>' data-delay='.5' data-increment="1"><?php echo e($ventas); ?><span class="fsz-def"></span></h1>
                    <h3 class="c-white">Ventas</h3>
                </div>
                <div class="pos-r">
                    <button type="button" class="mT-nv-50 pos-a r-10 t-2 btn cur-p bdrs-50p p-0 w-3r h-3r btn-danger mb-3 border-white">
                        <i class="ti-shopping-cart"></i>
                    </button>
                    <ul class="m-0 p-0 mT-20 mb-3">
                    </ul>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="bdrs-3 ov-h bgc-white border-0">
                <div class="bg-info ta-c p-30">
                    <h1 class="fw-300 mB-5 lh-1 c-white numscroller" data-slno='1' data-min='0' data-max='<?php echo e($pedidos); ?>' data-delay='.5' data-increment="1"><?php echo e($pedidos); ?><span class="fsz-def"></span></h1>
                    <h3 class="c-white">Pedidos</h3>
                </div>
                <div class="pos-r">
                    <button type="button" class="mT-nv-50 pos-a r-10 t-2 btn cur-p bdrs-50p p-0 w-3r h-3r btn-info mb-3 border-white">
                        <i class="ti-package"></i>
                    </button>
                    <ul class="m-0 p-0 mT-20 mb-3">
                    </ul>
                </div>
            </div>
        </div>

    </div>

    <div class="row mt-4">
        <div class="col-xs-12 col-lg-4 col-sm-12">
            <h6 class="text-info">PRODUCTOS RECIENTEMENTE AÑADIDOS</h6>
            <table id="tablaCajas" class="table table-hover" cellspacing="0" width="100%">
                <thead class="bg-info text-white">
                <tr align="center">
                    <th><i class="ti-image"></i></th>
                    <th>Id</th>
                    <th>Nombre</th>
                </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $agregados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr  align="center">
                                <td><img src="<?php echo e(Storage::url($producto->imagen)); ?>" width="60"></td>
                                <td><?php echo e($producto->id); ?></td>
                                <td><?php echo e($producto->nombre); ?></td>
                            </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <div class="col-xs-12 col-lg-8 col-sm-12">
            <h4 class="text-info text-center">CALENDARIO</h4>
            <div id="calendar"></div>
        </div>

    </div>

</div>


<script src="<?php echo e(asset('js/moment.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/fullcalendar.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/locale/es.js')); ?>"></script>

<script type="text/javascript">
$(function() {
    $('#calendar').fullCalendar({
        header: {
            left: 'prev,next today',
            center: 'title',
            right: 'month,agendaWeek,agendaDay,listWeek'
        },
        defaultDate: '<?=date("Y-m-d")?>',
        navLinks: true, // can click day/week names to navigate views
        editable: false,
        eventLimit: true, // allow "more" link when too many events
        locale: 'es',
        events: [
        {
            title: 'Hoy',
            start: '<?=date("Y-m-d")?>',
        }
        ]
    });

});  
    
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>