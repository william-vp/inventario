<?php $__env->startSection('title', 'Pagina no encontrada'); ?>
<?php $__env->startSection('color-style', 'bg-primary'); ?>
<?php $__env->startSection('content'); ?>

	<div class="col-sm-10 text-center" align="left">
		<img src="<?php echo e(Storage::url('public/notfound.jpg')); ?>" width="400" class="text-left">

		<a class="btn btn-outline-info" href="<?php echo e(URL::previous()); ?>"><i class="ti-back-left"></i> Regresar a la pagina anterior</a>
		<a class="btn btn-outline-success" href="<?php echo e(url('/')); ?>"><i class="ti-home"></i> Regresar a la pagina de Inicio</a>

	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>