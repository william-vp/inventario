<?php $__env->startSection('title', 'Lista de Usuarios'); ?>
<?php $__env->startSection('color-style', 'bg-success'); ?>
<?php $__env->startSection('content'); ?>
    <table id="tablaUsers" class="table table-hover" cellspacing="0" width="100%">
        <thead>
        <tr>
            <th>Id</th>
            <th class="text-center"><i class="ti-image"></i></th>
            <th>Nombre</th>
            <th>Cargo</th>
            <th>E-mail</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id</th>
            <th class="text-center"><i class="ti-image"></i></th>
            <th>Nombre</th>
            <th>Cargo</th>
            <th>E-mail</th>
            <th>Acciones</th>
        </tr>
        </tfoot>
        <tbody>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user->id); ?></td>
                <td><img width="60" src="<?php echo e(Storage::url($user->avatar)); ?>" alt=""></td>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->type); ?></td>
                <td><?php echo e($user->email); ?></td>
                <td>
                    <!--<a href="{ route('users.destroy', $user->id) }}"  data-toggle="tooltip" title="Eliminar Usuario" onclick="return confirm('¿Seguro quieres eliminar a este Usuario?')" class="btn btn-danger"><i class="ti-trash"></i></a>-->
                    <a href="<?php echo e(route('users.edit', $user->id)); ?>"  data-toggle="tooltip" title="Editar datos de usuario." class="btn btn-warning"><i class="ti-pencil text-white"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>

    <script src="<?php echo e(asset('js/scripts/auth.js')); ?>"></script>
    <script type="text/javascript">
        $('#tablaUsers').DataTable({
            "order": [[1, "asc"]]
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>