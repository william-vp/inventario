<?php $__env->startSection('title', 'Editar Cliente'); ?>
<?php $__env->startSection('color-style', 'bg-primary'); ?>
<?php $__env->startSection('content'); ?>
    <style>
        .modal-dialog-search {
            max-width: 80%;
            margin: 1.75rem auto;
        }

        .inputProd{
            width: 100px !important;
        }

        @media (max-width:991px){
            .modal-dialog-search {
                max-width: 100%;
                margin: 10px;
                margin-right: -25px;
                font-size: 12px;
            }
            .inputProd{
                width: 65px !important;
                margin: 0px;
            }
            .hideTd{
                display: none;
            }

        }

    </style>    
    <div class="text-left container mb-3 p-0">
        <a class="btn btn-outline-primary" href="<?php echo e(URL::previous()); ?>"><i class="ti-arrow-left"></i> Volver</a>
    </div>

    <div class="container">
        <div class="box-body">
            <div class="row">
                <!-- *********************** Purchase ************************** -->
                <div class="col-md-12 col-sm-12">
                    <form name="formEditCliente" id="formEditCliente">
                        <div class="box box-info">
                            <div class="box-header box-header-background-light with-border">
                                <h3 class="box-title text-center text-primary">DATOS DE CLIENTE</h3><br>
                            </div>
                            <div class="box-background">
                                <div class="box-body">
                                    <div class="row mt-3">
                                        <div class="col-md-3">
                                            <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                                            <label><span class="fa fa-address-card-o"></span> Id: </label>
                                            <div class="input-group">
                                                <input type="text" class="form-control"  data-toggle="tooltip" title="Recomendable No cambiar el id del cliente." placeholder="Id Cliente" name="id" id="id_edit" value="<?php echo e($cliente->id); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <label><span class="ti-user"></span> Nombre: </label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Nombre Cliente" name="nombre" id="nombre_edit" value="<?php echo e($cliente->nombre); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <label><span class="fa fa-envelope"></span> Direccion: </label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" placeholder="Correo Electrónico" name="direccion" id="direccion_edit" value="<?php echo e($cliente->direccion); ?>">
                                            </div>
                                        </div>

                                        <div class="col-md-3">
                                            <label><span class="fa fa-phone"></span> Teléfono: </label>
                                            <div class="input-group">
                                                <input type="tel" class="form-control" placeholder="Telefono" name="telefono" id="telefono_edit" value="<?php echo e($cliente->telefono); ?>">
                                            </div>
                                        </div>

                        
                                    </div>
                                </div><!-- /.box-body -->
                            </div>
                        </div>

                        <div class="row box-info mt-5">

                            <div class="col-md-12 text-center">
                                <button type="button" id="btnUpdate" class="btn btn-success"><i class="ti-save"></i> Guardar datos</button> 
                                <button type="reset" class="btn btn-info"><i class="ti-save"></i> Restablecer datos</button> 
                            </div>
                            
                        </div>
            </form>

                </div>
            </div>
        </div>
    </div>

<script src="<?php echo e(asset('js/scripts/cliente.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>