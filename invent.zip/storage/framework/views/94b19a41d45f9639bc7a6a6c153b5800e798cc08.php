<?php $__env->startSection('title', 'Productos'); ?>
<?php $__env->startSection('color-style', 'bg-primary'); ?>
<?php $__env->startSection('content'); ?>
    <h4 class="c-grey-900 mB-20 text-primary">Lista de Productos</h4>

    <div class="text-left container mb-3 p-0">
        <a class="btn btn-outline-primary" href="<?php echo e(URL::previous()); ?>"><i class="ti-arrow-left"></i> Volver</a>
        <a href="<?php echo e(url('/productos/create')); ?>" class="btn cur-p btn-outline-success"><i class="ti-plus"></i> NUEVO PRODUCTO</a>
    </div>

    <table id="tablaProductos" class="table table-hover" cellspacing="0" width="100%">
        <thead>
        <tr>
            <th>Id</th>
            <th><i class="ti-image"></i></th>
            <th>Nombre</th>
            <th>Precio Compra</th>
            <th>Precio Venta</th>
            <th>Cant. Mostrador</th>
            <th>Cant. Bodega</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id</th>
            <th><i class="ti-image"></i></th>
            <th>Nombre</th>
            <th>Precio Compra</th>
            <th>Precio Venta</th>
            <th>Cant. Mostrador</th>
            <th>Cant. Bodega</th>
            <th>Estado</th>
            <th>Acciones</th>
        </tr>
        </tfoot>
        <tbody>
        <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($producto ->id); ?></td>
                <td><img width="90" src="<?php echo e(Storage::url($producto->imagen)); ?>" alt=""></td>
                <td><?php echo e($producto->nombre); ?></td>
                <td><?php echo e($producto->precio_compra); ?></td>
                <td><?php echo e($producto->precio_venta); ?></td>
                <td><?php echo e($producto->mostrador); ?></td>
                <td><?php echo e($producto->existencias); ?></td>
                <?php if($producto->estado): ?>
                    <td><span class="badge badge-pill bg-success text-white">ACTIVO</span></td>
                <?php else: ?>
                    <td><span class="badge badge-pill bg-danger text-white">INACTIVO</span></td>
                <?php endif; ?>
                <td id="tdAcciones_<?php echo e($producto ->id); ?>">
                    <a href="<?php echo e(route('productos.edit', $producto->id)); ?>" data-toggle="tooltip" title="Editar Producto" class="btn btn-warning"><i class="ti-pencil text-white"></i></a>

                    <a href="<?php echo e(route('productos.traslado', $producto->id)); ?>" data-toggle="tooltip" title="Realizar Translado" class="btn btn-success"><i class=" ti-exchange-vertical text-white"></i></a>
                   

                    <a href="<?php echo e(route('productos.changeStatus', $producto->id)); ?>" data-toggle="tooltip" title="Cambiar Estado"   class="btn btn-info"><i class="ti-reload text-white"></i></a>

                    <!--<a href="<?php echo e(route('productos.destroy', $producto->id)); ?>"  data-toggle="tooltip" title="Eliminar Producto"  onclick="return confirm('¿Seguro quieres eliminar a esta producto ?')" class="btn btn-danger"><i class="ti-trash"></i></a>-->
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

        </tbody>
    </table>


    <?php if(isset($_GET['search'])): ?>
        <script type="text/javascript">
            $('#tablaProductos').DataTable({
                "order": [[1, "asc"]],
                "search": {
                    "search": "<?php echo e($_GET['search']); ?>"
                }
            });
        </script>
    <?php else: ?>
        <script type="text/javascript">
            $('#tablaProductos').DataTable({
                "order": [[1, "asc"]],
            });
        </script>
    <?php endif; ?>
    <script src="<?php echo e(asset('js/scripts/producto.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>