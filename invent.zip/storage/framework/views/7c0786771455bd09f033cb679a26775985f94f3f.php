<?php $__env->startSection('title', 'Clientes'); ?>
<?php $__env->startSection('color-style', 'bg-info'); ?>
<?php $__env->startSection('content'); ?>

    <h4 class=" mB-20 text-center text-info">LISTA DE CLIENTES</h4>

    <div class="text-left container mb-3 p-0">
        <a class="btn btn-outline-primary" href="<?php echo e(URL::previous()); ?>"><i class="ti-arrow-left"></i> Volver</a>
        <a  data-toggle="modal" data-target="#ModalNuevoCliente" class="btn btn-outline-info"><i class="ti-plus"></i> NUEVO CLIENTE</a>
    </div>

    <table id="tablaClientes" class="table table-hover" cellspacing="0" width="100%">
        <thead>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th style="max-width: 200px;">Dirección</th>
            <th>Telefono</th>
            <th>Acciones</th>
        </tr>
        </thead>
        <tfoot>
        <tr>
            <th>Id</th>
            <th>Nombre</th>
            <th>Dirección</th>
            <th>Telefono</th>
            <th>Acciones</th>
        </tr>
        </tfoot>
        <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cliente->id); ?></td>
                <td><?php echo e($cliente->nombre); ?></td>
                <td><?php echo e($cliente->direccion); ?></td>
                <td><?php echo e($cliente->telefono); ?></td>
                <td>
                    <a href="<?php echo e(route('clientes.destroy', $cliente->id)); ?>"  data-toggle="tooltip" title="Eliminar Cliente"  onclick="return confirm('¿Seguro quieres eliminar a este Usuario?')" class="btn btn-danger"><i class="ti-trash"></i></a>
                    <a href="<?php echo e(route('clientes.edit', $cliente->id)); ?>" class="btn btn-warning"  data-toggle="tooltip" title="Editar Cliente" ><i class="ti-pencil text-white"></i></a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
    </table>

    <!-- MODAL agregar CLIENTE -->
    <div id="ModalNuevoCliente" class="modal fade" role="dialog">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-info text-white rounded-0 text-center">
                    <h4 class="modal-title" >NUEVO CLIENTE</h4>
                    <button type="button" class="close" data-dismiss="modal">×</button>
                </div>
                <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                <div class="modal-body p-5" align="center">
                    <form class="form mb-4" role="form" id="formNuevoCliente"><br><br>
                        <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                        <div class="form-group">
                            <label class="col-sm-12">Id:</label>
                            <div class="col-sm-8">
                                <input placeholder="Identificación de Cliente" autocomplete="off" type="text" class="form-control" name="id" id="id_add" autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-12">Nombre:</label>
                            <div class="col-sm-8">
                                <input placeholder="Nombre de Cliente" type="text" autocomplete="off" class="form-control" name="nombre" id="nombre_add" autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-12">Dirección (Opcional):</label>
                            <div class="col-sm-8">
                                <input placeholder="Dirección del Cliente" type="text" autocomplete="off" class="form-control" name="direccion" id="direccion_add" autofocus>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="col-sm-12">Teléfono:</label>
                            <div class="col-sm-8">
                                <input placeholder="Telefono - Celular " type="tel" autocomplete="off" class="form-control" name="telefono" id="telefono_add" autofocus>
                            </div>
                        </div>

                        <div class="modal-footer text-center" align="center">
                            <button type="button" class="btn btn-success btnClientAdd">
                                <span class='glyphicon glyphicon-plus'></span> AGREGAR
                            </button>
                            <button type="button" class="btn btn-primary" data-dismiss="modal">
                                <span class='glyphicon glyphicon-remove'></span> CERRAR
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!--// MODAL agregar CLIENTE -->


    <script src="<?php echo e(asset('js/scripts/cliente.js')); ?>"></script>

    <?php if(isset($_GET['search'])): ?>
        <script type="text/javascript">
            $('#tablaClientes').DataTable({
                "order": [[1, "asc"]],
                "search": {
                    "search": "<?php echo e($_GET['search']); ?>"
                }
            });
        </script>
    <?php else: ?>
        <script type="text/javascript">
            $('#tablaClientes').DataTable({
                "order": [[1, "asc"]],
            });
        </script>
    <?php endif; ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>