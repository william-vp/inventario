<?php

use Faker\Generator as Faker;

$factory->define(App\DetallesPedido::class, function (Faker $faker) {
    return [
        //
    ];
});
