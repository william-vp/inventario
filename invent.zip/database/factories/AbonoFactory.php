<?php

use Faker\Generator as Faker;

$factory->define(App\Abono::class, function (Faker $faker) {
    return [
        //
    ];
});
