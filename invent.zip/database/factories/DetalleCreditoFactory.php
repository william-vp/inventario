<?php

use Faker\Generator as Faker;

$factory->define(App\DetalleCredito::class, function (Faker $faker) {
    return [
        //
    ];
});
