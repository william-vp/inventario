<?php

use Faker\Generator as Faker;

$factory->define(App\Detalle::class, function (Faker $faker) {
    return [
        //
    ];
});
