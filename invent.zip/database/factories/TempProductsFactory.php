<?php

use Faker\Generator as Faker;

$factory->define(App\TempProducts::class, function (Faker $faker) {
    return [
        //
    ];
});
